"""
Operational Signal Forge - Sensor Fusion Engine
==================================================
Lambda function that ingests ground sensor readings (GPR, thermal, acoustic)
from Kinesis, fuses them into a per-grid-cell "person-present probability"
score, and writes results to DynamoDB for the dashboard / alerting layer.

Grid cells are keyed by geohash (precision 8 ~ 19m x 19m), which gives us:
  - Natural geospatial partitioning in DynamoDB
  - Easy radius queries for the dashboard
  - Stable cell IDs across multiple sensor passes
"""

import json
import os
import time
import math
import boto3
import geohash2 as geohash  # pip install geohash2 --break-system-packages

dynamodb = boto3.resource("dynamodb")
sns = boto3.client("sns")

TABLE_NAME = os.environ.get("DETECTIONS_TABLE", "signal-forge-detections")
ALERT_TOPIC_ARN = os.environ.get("ALERT_TOPIC_ARN")
HIGH_CONFIDENCE_THRESHOLD = float(os.environ.get("HIGH_CONFIDENCE_THRESHOLD", "0.75"))
GEOHASH_PRECISION = 8

table = dynamodb.Table(TABLE_NAME)


# ---------------------------------------------------------------------------
# Signal scoring functions
# ---------------------------------------------------------------------------
# Each scoring function returns a 0.0-1.0 confidence that the signal
# indicates a live person, based on known signatures from USAR field guides
# (FEMA US&R, INSARAG). These are heuristic baselines meant to be tuned
# against real sensor calibration data from the field units in use.

def score_radar(reading: dict) -> float:
    """
    Ground-penetrating / through-rubble radar.
    Looks for periodic micro-movement signatures (breathing ~0.2-0.5Hz,
    heartbeat ~1-1.5Hz) layered on top of a void/anomaly return.
    reading: { "void_detected": bool, "doppler_periodicity_hz": float,
               "doppler_amplitude": float, "depth_m": float }
    """
    if not reading.get("void_detected"):
        return 0.0

    periodicity = reading.get("doppler_periodicity_hz", 0)
    amplitude = reading.get("doppler_amplitude", 0)

    # Breathing-band micro-Doppler is the strongest live-person indicator
    breathing_band = 0.15 <= periodicity <= 0.6
    cardiac_band = 0.8 <= periodicity <= 2.0

    base = 0.0
    if breathing_band:
        base = 0.6
    elif cardiac_band:
        base = 0.45

    # Amplitude scales confidence (clamped)
    amplitude_factor = min(amplitude / 1.0, 1.0)
    score = base + (0.35 * amplitude_factor)

    # Depth penalty - deeper burial = weaker/noisier signal, slightly discount
    depth = reading.get("depth_m", 0)
    if depth > 4:
        score *= 0.85

    return min(score, 1.0)


def score_thermal(reading: dict) -> float:
    """
    Thermal/IR camera or borescope reading.
    reading: { "delta_t_celsius": float, "hotspot_size_cm2": float,
               "ambient_c": float }
    Human body-heat signature is ~30-37C against typically cooler rubble
    (concrete, masonry) or hotter rubble in fire-related collapse contexts.
    """
    delta_t = reading.get("delta_t_celsius", 0)
    hotspot_size = reading.get("hotspot_size_cm2", 0)

    if delta_t <= 0:
        return 0.0

    # Strongest signal in the 3-8C delta range (typical clothed-body vs rubble)
    if 3 <= delta_t <= 8:
        temp_score = 0.7
    elif delta_t > 8:
        temp_score = 0.4  # could be fire/electrical, less specific
    else:
        temp_score = 0.3 * (delta_t / 3)

    # A plausible body-sized hotspot (roughly torso/head size through a gap)
    size_score = min(hotspot_size / 600, 1.0)  # 600cm2 ~ a torso-sized patch

    return min(temp_score * 0.7 + size_score * 0.3, 1.0)


def score_acoustic(reading: dict) -> float:
    """
    Acoustic/seismic listening device (tapping, voice, scratching).
    reading: { "tap_pattern_detected": bool, "voice_likelihood": float,
               "snr_db": float }
    """
    score = 0.0
    if reading.get("tap_pattern_detected"):
        score += 0.6  # rhythmic tapping is a deliberate, high-value signal
    voice_likelihood = reading.get("voice_likelihood", 0.0)
    score += 0.4 * voice_likelihood

    snr = reading.get("snr_db", 0)
    if snr < 6:
        score *= 0.7  # noisy read, discount confidence

    return min(score, 1.0)


def fuse_scores(radar_score: float, thermal_score: float, acoustic_score: float,
                 weights=(0.4, 0.3, 0.3)) -> float:
    """
    Weighted fusion with a corroboration bonus: agreement across independent
    sensor modalities is much stronger evidence than one strong reading alone.
    """
    w_r, w_t, w_a = weights
    base = (radar_score * w_r) + (thermal_score * w_t) + (acoustic_score * w_a)

    active_signals = sum(1 for s in (radar_score, thermal_score, acoustic_score) if s > 0.3)
    corroboration_bonus = {1: 0.0, 2: 0.10, 3: 0.20}.get(active_signals, 0.0)

    return round(min(base + corroboration_bonus, 1.0), 3)


# ---------------------------------------------------------------------------
# Lambda handler
# ---------------------------------------------------------------------------

def handler(event, context):
    """
    Triggered by Kinesis. Each record is a sensor reading:
    {
      "sensor_id": "GPR-014",
      "sensor_type": "radar" | "thermal" | "acoustic",
      "lat": 10.4806, "lon": -66.9036,
      "timestamp": 1719500000,
      "reading": { ...type-specific fields... },
      "site_id": "caracas-site-7"
    }
    """
    results = []

    for record in event.get("Records", []):
        payload = json.loads(record["kinesis"]["data"])
        results.append(process_reading(payload))

    return {"processed": len(results), "alerts_fired": sum(1 for r in results if r.get("alert"))}


def process_reading(payload: dict) -> dict:
    lat, lon = payload["lat"], payload["lon"]
    cell_id = geohash.encode(lat, lon, precision=GEOHASH_PRECISION)
    sensor_type = payload["sensor_type"]
    reading = payload["reading"]

    score_fn = {
        "radar": score_radar,
        "thermal": score_thermal,
        "acoustic": score_acoustic,
    }[sensor_type]
    signal_score = score_fn(reading)

    cell = get_or_create_cell(cell_id, lat, lon, payload.get("site_id"))
    cell[f"{sensor_type}_score"] = signal_score
    cell[f"{sensor_type}_last_updated"] = int(time.time())

    fused = fuse_scores(
        cell.get("radar_score", 0.0),
        cell.get("thermal_score", 0.0),
        cell.get("acoustic_score", 0.0),
    )
    cell["fused_probability"] = fused
    cell["updated_at"] = int(time.time())

    table.put_item(Item=cell)

    alert = False
    if fused >= HIGH_CONFIDENCE_THRESHOLD and ALERT_TOPIC_ARN:
        fire_alert(cell)
        alert = True

    return {"cell_id": cell_id, "fused_probability": fused, "alert": alert}


def get_or_create_cell(cell_id, lat, lon, site_id):
    resp = table.get_item(Key={"cell_id": cell_id})
    if "Item" in resp:
        return resp["Item"]
    return {
        "cell_id": cell_id,
        "lat": lat,
        "lon": lon,
        "site_id": site_id,
        "radar_score": 0.0,
        "thermal_score": 0.0,
        "acoustic_score": 0.0,
        "fused_probability": 0.0,
        "status": "unassigned",  # unassigned | searching | cleared | confirmed
        "created_at": int(time.time()),
    }


def fire_alert(cell: dict):
    message = (
        f"HIGH-CONFIDENCE DETECTION\n"
        f"Cell: {cell['cell_id']} ({cell['lat']:.5f}, {cell['lon']:.5f})\n"
        f"Site: {cell.get('site_id', 'unknown')}\n"
        f"Fused probability: {cell['fused_probability']}\n"
        f"Radar: {cell.get('radar_score')}  Thermal: {cell.get('thermal_score')}  "
        f"Acoustic: {cell.get('acoustic_score')}\n"
        f"Dispatch search team immediately."
    )
    sns.publish(
        TopicArn=ALERT_TOPIC_ARN,
        Subject="Signal Forge: High-confidence detection",
        Message=message,
    )